package edu.msudenver.lab_04

class FragmentMapsBinding {
    val btnParkedHere: Any
    val root: View?

    companion object {
        fun inflate(inflater: LayoutInflater, container: ViewGroup?, b: Boolean): FragmentMapsBinding {

        }
    }

}
